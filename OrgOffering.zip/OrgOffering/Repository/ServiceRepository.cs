﻿using OrgOffering.Data;
using OrgOffering.Models;
using System.Linq;

namespace OrgOffering.Repository
{
    public class ServiceRepository : GenericRepository <Service>, IServiceRepository
    {
        public ServiceRepository(Project3DatabaseContext context) : base(context)
        {
        }

    }
}
