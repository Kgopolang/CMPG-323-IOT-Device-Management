﻿using Microsoft.EntityFrameworkCore;
using OrgOffering.Data;
using OrgOffering.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OrgOffering.Repository
{
    public class ProductRepository : GenericRepository<Product>, IProductRepository
    {
        public ProductRepository(Project3DatabaseContext context) : base(context)
        {
        }

    }
}
